module.exports = {
    registerVehicle : require('./register'),
    retrieveAllVehicle : require('./retrieve-all'),
    retrieveVehicle : require('./retrieve'),
    updateVehicle : require('./update'),
    unregisterVehicle : require('./unregister')
}




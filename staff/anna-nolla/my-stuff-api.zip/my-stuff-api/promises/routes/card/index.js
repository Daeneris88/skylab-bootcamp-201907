module.exports = {
    registerCard : require('./register'),
    retrieveAllCard : require('./retrieve-all'),
    retrieveCard : require('./retrieve'),
    unregisterCard : require('./unregister')
}




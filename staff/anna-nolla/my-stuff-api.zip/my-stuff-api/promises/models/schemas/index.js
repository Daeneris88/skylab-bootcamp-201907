module.exports = {
    user: require('./user'),
    vehicle: require('./vehicle'),
    property: require('./property'),
    card: require('./card')
}
module.exports = {
    registerCard: require('./register'),
    retrieveCard: require('./retrieve'),
    unregisterCard: require('./unregister'),
}
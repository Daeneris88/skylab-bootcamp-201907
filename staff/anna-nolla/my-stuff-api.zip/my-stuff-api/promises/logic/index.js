module.exports = {
    ...require('./user'),
    ...require('./vehicle'),
    ...require('./property'),
    ...require('./card')
}

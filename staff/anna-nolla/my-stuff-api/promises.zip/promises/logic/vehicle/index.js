module.exports = {
    registerCar: require('./register'),
    retrieveAllCar: require('./retrieve-all'),
    retrieveCar: require('./retrieve'),
    updateCar: require('./update'),
    unregisterCar: require('./unregister'),
}
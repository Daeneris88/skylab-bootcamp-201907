const validate = require('../../../utils/validate')
const { Property } = require('../../../models')

/**
 * 
 * @param {*} id
 * 
 * @returns {Promise}
*/

module.exports = function(id) {
    
    validate.string(id, 'Property id')
    let owner = []

    return Property.findById(id)
        .then(property => {
            if (!property) throw Error(`Property with id ${id} does not exist.`)
            else {
                property.owners.forEach(item => {
                    item.toString()
                    owner.push(item)
                })
                property.owners = owner
                property.id = id
                return property
            }
        })
}
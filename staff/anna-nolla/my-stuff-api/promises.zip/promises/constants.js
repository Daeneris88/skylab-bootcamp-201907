module.exports = {
    HOME: '/',
    SEARCH: '/search',
    SIGN_IN: '/sign-in',
    SIGN_UP: '/sign-up',
    SIGN_OUT: '/sign-out',
    DETAIL: '/ducks',
    TOGGLE_FAV: '/toggle-favorite',
    LOCALE: '/locale',
    FAVORITES: '/favorites'
}